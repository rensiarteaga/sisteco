<?php
//Enzo>: comentado para evitar que el archivo de session se cree en esta pagina.Para  hacer que se cree 
//solo una vez que un usuario se autentique.
//session_start();
?>

<html> 
<head> 
<title>ENDESIS</title> 	
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-15">
<script type="text/javascript">
window.location='sis_seguridad/vista/_adm/index.html';
</script>
</head>
<body>
</body>
</html>