
<div> 
<div>
<img src="../../../lib/images/bienvenida_2.jpg" width="100%" height="100%" />

</div>
</div>

